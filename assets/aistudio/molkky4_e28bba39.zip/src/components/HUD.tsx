import React, { useState } from 'react';
import { History, RotateCcw, HelpCircle, X } from 'lucide-react';
import { ThrowRecord } from '../types/game';
import { sound } from '../audio/soundEffects';

interface HUDProps {
  score: number;
  missStreak: number;
  round: number;
  history: ThrowRecord[];
  lastBanner: { message: string; sub?: string; type: 'success' | 'bust' | 'miss' | 'info' } | null;
  onResetGame: () => void;
  onOpenRules: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  score,
  missStreak,
  round,
  history,
  lastBanner,
  onResetGame,
  onOpenRules,
}) => {
  const [showHistory, setShowHistory] = useState(false);

  const remaining = Math.max(0, 50 - score);
  const progressPercent = Math.min(100, (score / 50) * 100);

  return (
    <>
      {/* Top HUD Wrapper (Low-occlusion: Center is 100% empty) */}
      <div className="absolute top-2 left-2 right-2 sm:top-3 sm:left-4 sm:right-4 pointer-events-none select-none z-20 flex justify-between items-start">
        {/* Left Side: Round display on top, and Compact Score Card placed directly underneath */}
        <div className="flex flex-col items-start gap-1.5 pointer-events-auto">
          {/* Top row: Round badge & Reset button (Shifted higher) */}
          <div className="flex items-center gap-1.5">
            <div className="px-2.5 py-1 rounded-lg bg-stone-900/90 text-amber-200 border border-stone-800 shadow-md font-mono text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5">
              <span>ROUND</span>
              <span className="text-amber-400 text-xs font-black">{round}</span>
            </div>

            <button
              type="button"
              tabIndex={-1}
              onClick={e => {
                e.currentTarget.blur();
                sound.playClick();
                onResetGame();
              }}
              onPointerDown={e => {
                e.stopPropagation();
                e.currentTarget.blur();
              }}
              className="p-1.5 rounded-lg bg-stone-900/85 hover:bg-stone-800 text-stone-400 hover:text-white border border-stone-800 shadow-md transition active:scale-95 cursor-pointer outline-none"
              title="リセット (最初からやり直し)"
            >
              <RotateCcw size={13} />
            </button>
          </div>

          {/* Compact Score Card placed directly UNDER the Round display */}
          <div className="flex flex-col items-start bg-stone-950/90 border border-amber-600/40 rounded-xl px-3 py-1.5 shadow-[0_4px_16px_rgba(0,0,0,0.5)]">
            <div className="flex items-baseline gap-1.5">
              <span className="text-stone-400 text-[10px] font-bold tracking-wider uppercase">Score</span>
              <span className="text-2xl sm:text-3xl font-black tabular-nums tracking-tight text-amber-400">
                {score}
              </span>
              <span className="text-stone-400 text-xs font-semibold">/ 50</span>
            </div>

            {/* Compact Progress bar */}
            <div className="w-28 sm:w-32 h-1.5 bg-stone-850 rounded-full mt-1 overflow-hidden border border-stone-700/50">
              <div
                className={`h-full transition-all duration-500 rounded-full ${
                  score > 40
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-300'
                    : 'bg-gradient-to-r from-amber-600 to-amber-400'
                }`}
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            <div className="text-[10px] font-bold text-amber-200/90 mt-0.5">
              {remaining === 0 ? '✨ GOAL!' : `あと ${remaining} 点`}
            </div>
          </div>
        </div>

        {/* Temporary Round Outcome Banner (Floats gently below the unobstructed center) */}
        {lastBanner && (
          <div className="pointer-events-auto absolute top-2 left-1/2 -translate-x-1/2 animate-fade-in transition-all max-w-[90vw]">
            <div
              className={`px-4 py-2 rounded-xl shadow-2xl border text-center font-bold text-xs sm:text-sm flex flex-col items-center gap-0.5 ${
                lastBanner.type === 'success'
                  ? 'bg-amber-950/95 border-amber-500/70 text-amber-200'
                  : lastBanner.type === 'bust'
                  ? 'bg-red-950/95 border-red-500/70 text-red-200'
                  : lastBanner.type === 'miss'
                  ? 'bg-stone-900/95 border-stone-600 text-stone-300'
                  : 'bg-stone-900/95 border-amber-600/30 text-amber-100'
              }`}
            >
              <span className="tracking-wide text-white drop-shadow-sm">{lastBanner.message}</span>
              {lastBanner.sub && (
                <span className="text-[11px] font-medium opacity-90">{lastBanner.sub}</span>
              )}
            </div>
          </div>
        )}

        {/* Right Side: Miss Strikes, History & Rules (Shifted higher to match) */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          {/* Strike indicator (3 misses = disqualified) */}
          <div className="px-2.5 py-1 rounded-lg bg-stone-900/90 border border-stone-800 shadow-md flex items-center gap-1.5">
            <span className="text-[10px] text-stone-400 font-bold uppercase hidden sm:inline">ミス:</span>
            <div className="flex items-center gap-1">
              {[1, 2, 3].map(i => {
                const isStrike = missStreak >= i;
                return (
                  <span
                    key={i}
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-bold ${
                      isStrike
                        ? 'bg-red-500 text-white shadow-[0_0_6px_rgba(239,68,68,0.8)]'
                        : 'bg-stone-800 text-stone-600 border border-stone-700'
                    }`}
                  >
                    {isStrike ? '✕' : '•'}
                  </span>
                );
              })}
            </div>
          </div>

          {/* History drawer button */}
          <button
            type="button"
            tabIndex={-1}
            onClick={e => {
              e.currentTarget.blur();
              sound.playClick();
              setShowHistory(!showHistory);
            }}
            onPointerDown={e => {
              e.stopPropagation();
              e.currentTarget.blur();
            }}
            className="p-1.5 rounded-lg bg-stone-900/85 hover:bg-stone-800 text-stone-300 hover:text-white border border-stone-800 shadow-md transition active:scale-95 cursor-pointer relative outline-none"
            title="投擲履歴"
          >
            <History size={14} />
            {history.length > 0 && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-500 text-stone-950 font-black text-[8px] rounded-full flex items-center justify-center">
                {history.length}
              </span>
            )}
          </button>

          {/* Rules button */}
          <button
            type="button"
            tabIndex={-1}
            onClick={e => {
              e.currentTarget.blur();
              sound.playClick();
              onOpenRules();
            }}
            onPointerDown={e => {
              e.stopPropagation();
              e.currentTarget.blur();
            }}
            className="p-1.5 rounded-lg bg-stone-900/85 hover:bg-stone-800 text-stone-300 hover:text-white border border-stone-800 shadow-md transition active:scale-95 cursor-pointer outline-none"
            title="ルール説明"
          >
            <HelpCircle size={14} />
          </button>
        </div>
      </div>

      {/* Throw History Slide-over Drawer */}
      {showHistory && (
        <div
          onPointerDown={e => e.stopPropagation()}
          className="absolute inset-y-0 right-0 w-80 max-w-[85vw] bg-stone-950/95 border-l border-stone-800 z-40 p-4 sm:p-5 flex flex-col shadow-2xl text-stone-200"
        >
          <div className="flex items-center justify-between pb-3 border-b border-stone-800">
            <div className="flex items-center gap-2">
              <History size={16} className="text-amber-400" />
              <h2 className="font-bold text-amber-100 text-sm">投擲の履歴</h2>
            </div>
            <button
              type="button"
              tabIndex={-1}
              onClick={e => {
                e.currentTarget.blur();
                setShowHistory(false);
              }}
              onPointerDown={e => e.currentTarget.blur()}
              className="p-1 rounded-lg hover:bg-stone-800 text-stone-400 hover:text-white outline-none cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto my-3 space-y-2 pr-1">
            {history.length === 0 ? (
              <div className="text-center text-xs text-stone-500 py-8">
                まだ投擲がありません。<br />モルック棒を投げてみましょう！
              </div>
            ) : (
              history.map((rec, i) => (
                <div
                  key={i}
                  className={`p-2.5 rounded-xl border text-xs flex flex-col gap-1 ${
                    rec.isBust
                      ? 'bg-red-950/40 border-red-800/60 text-red-200'
                      : rec.isMiss
                      ? 'bg-stone-900/60 border-stone-800 text-stone-400'
                      : 'bg-amber-950/30 border-amber-800/40 text-amber-100'
                  }`}
                >
                  <div className="flex items-center justify-between font-mono">
                    <span className="font-bold text-stone-400">R{rec.round}</span>
                    <span
                      className={`font-black text-sm tabular-nums ${
                        rec.roundScore > 0 ? 'text-amber-400' : 'text-stone-400'
                      }`}
                    >
                      +{rec.roundScore} 点
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px]">
                    <span>
                      {rec.fallenCount === 1
                        ? `スキットル [${rec.fallenNumbers[0]}] を1本撃破`
                        : rec.fallenCount > 1
                        ? `${rec.fallenCount} 本倒した (${rec.fallenNumbers.join(', ')})`
                        : '全ミス (0点)'}
                    </span>
                    <span className="font-bold tabular-nums text-stone-300">
                      計 {rec.totalScoreAfter} 点
                    </span>
                  </div>

                  {rec.isBust && (
                    <div className="text-[10px] text-red-400 font-bold bg-red-900/30 px-2 py-0.5 rounded">
                      ⚠️ 50点超過ペナルティ → 25点へ減点
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

          <div className="pt-3 border-t border-stone-800 text-xs text-stone-400 flex justify-between">
            <span>累計投擲回数: {history.length}回</span>
            <span className="font-bold text-amber-400">現在: {score}点</span>
          </div>
        </div>
      )}
    </>
  );
};
