import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, Skull, RotateCcw, Share2, Award } from 'lucide-react';
import { ThrowRecord } from '../types/game';
import { sound } from '../audio/soundEffects';

interface GameOverModalProps {
  type: 'victory' | 'disqualified';
  score: number;
  history: ThrowRecord[];
  onRestart: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  type,
  score,
  history,
  onRestart,
}) => {
  const isVictory = type === 'victory';

  useEffect(() => {
    if (isVictory) {
      sound.playVictoryFanfare();
      // Confetti burst
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
      const t1 = setTimeout(() => {
        confetti({
          particleCount: 50,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
        });
        confetti({
          particleCount: 50,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
        });
      }, 400);
      return () => clearTimeout(t1);
    } else {
      sound.playMissSound();
    }
  }, [isVictory]);

  const totalThrows = history.length;
  const bestRoundScore = history.reduce((max, h) => Math.max(max, h.roundScore), 0);
  const bustsCount = history.filter(h => h.isBust).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/85 backdrop-blur-sm select-none animate-fade-in">
      <div className="bg-stone-900 border border-stone-700 rounded-3xl w-full max-w-md p-6 sm:p-8 shadow-2xl text-stone-100 flex flex-col items-center text-center gap-5">
        {/* Big Icon Header */}
        <div
          className={`w-20 h-20 rounded-3xl flex items-center justify-center shadow-xl ${
            isVictory
              ? 'bg-gradient-to-tr from-amber-600 to-yellow-400 text-stone-950 shadow-[0_8px_30px_rgba(245,158,11,0.5)]'
              : 'bg-stone-800 border border-red-500/40 text-red-400 shadow-[0_8px_30px_rgba(239,68,68,0.3)]'
          }`}
        >
          {isVictory ? <Trophy size={42} /> : <Skull size={42} />}
        </div>

        {/* Title */}
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-amber-50">
            {isVictory ? '50点ぴったり達成！' : '3連続ミスで失格！'}
          </h2>
          <p className="text-stone-400 text-xs sm:text-sm mt-1">
            {isVictory
              ? '見事なコントロールで50点ジャスト勝利を決めました！'
              : '3回連続でスキットルを1本も倒せなかったため失格です。'}
          </p>
        </div>

        {/* Match Stats Summary */}
        <div className="w-full grid grid-cols-3 gap-2 bg-stone-950/60 p-3.5 rounded-2xl border border-stone-800">
          <div className="flex flex-col items-center">
            <span className="text-[10px] text-stone-400 font-bold uppercase">最終スコア</span>
            <span className="text-xl sm:text-2xl font-black text-amber-400 tabular-nums">
              {score}点
            </span>
          </div>

          <div className="flex flex-col items-center border-x border-stone-800">
            <span className="text-[10px] text-stone-400 font-bold uppercase">投擲数</span>
            <span className="text-xl sm:text-2xl font-black text-stone-200 tabular-nums">
              {totalThrows}回
            </span>
          </div>

          <div className="flex flex-col items-center">
            <span className="text-[10px] text-stone-400 font-bold uppercase">最高一撃</span>
            <span className="text-xl sm:text-2xl font-black text-emerald-400 tabular-nums">
              +{bestRoundScore}点
            </span>
          </div>
        </div>

        {bustsCount > 0 && (
          <div className="text-xs text-rose-300 bg-rose-950/40 border border-rose-900/60 px-3 py-1.5 rounded-xl">
            ⚠️ 50点超過による25点ペナルティ: {bustsCount}回
          </div>
        )}

        {/* Restart Button */}
        <div className="w-full flex flex-col gap-2.5 pt-2">
          <button
            onClick={() => {
              sound.playClick();
              onRestart();
            }}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-stone-950 font-black text-base shadow-[0_6px_22px_rgba(245,158,11,0.4)] active:scale-95 transition cursor-pointer flex items-center justify-center gap-2"
          >
            <RotateCcw size={18} />
            もう一度挑戦する
          </button>
        </div>
      </div>
    </div>
  );
};
