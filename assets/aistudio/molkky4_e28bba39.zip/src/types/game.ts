export interface SkittleState {
  id: number;
  number: number;
  x: number;
  y: number;
  z: number;
  quaternion: [number, number, number, number];
  isFallen: boolean;
  scoreAwarded?: boolean;
}

export interface ThrowRecord {
  round: number;
  fallenCount: number;
  fallenNumbers: number[];
  roundScore: number;
  totalScoreBefore: number;
  totalScoreAfter: number;
  isBust: boolean;
  isMiss: boolean;
}

export type GamePhase = 'title' | 'aiming' | 'throwing' | 'settling' | 'result' | 'victory' | 'gameover';

export type CameraViewMode = 'thrower' | 'overhead' | 'side' | 'target' | 'follow';

export interface ThrowParams {
  aimAngle: number; // Left/Right angle in degrees (-25 to 25)
  pitchAngle: number; // Upwards pitch in degrees (5 to 45)
  power: number; // 30 to 100%
  spin: number; // -10 to 10
}
