import React from 'react';
import {
  ChevronDown,
  ChevronUp,
  Sliders,
  Sparkles,
  Volume2,
  VolumeX,
  Play,
  RotateCcw,
  Eye,
} from 'lucide-react';
import { CameraViewMode, ThrowParams } from '../types/game';
import { sound } from '../audio/soundEffects';

interface ControlDockProps {
  throwParams: ThrowParams;
  onChangeParams: (params: ThrowParams) => void;
  onThrow: () => void;
  canThrow: boolean;
  isSettling: boolean;
  cameraView: CameraViewMode;
  onChangeCameraView: (mode: CameraViewMode) => void;
  showTrajectory: boolean;
  onToggleTrajectory: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onResetPinsToStarting: () => void;
  isWaitingNextTurn: boolean;
  onNextTurnReady: () => void;
  isCollapsed: boolean;
  onToggleCollapsed: () => void;
  isThrowCooldown?: boolean;
}

export const ControlDock: React.FC<ControlDockProps> = ({
  throwParams,
  onChangeParams,
  onThrow,
  canThrow,
  isSettling,
  cameraView,
  onChangeCameraView,
  showTrajectory,
  onToggleTrajectory,
  soundEnabled,
  onToggleSound,
  onResetPinsToStarting,
  isWaitingNextTurn,
  onNextTurnReady,
  isCollapsed,
  onToggleCollapsed,
  isThrowCooldown = false,
}) => {
  const updateParam = <K extends keyof ThrowParams>(key: K, val: ThrowParams[K]) => {
    onChangeParams({
      ...throwParams,
      [key]: val,
    });
  };

  return (
    <>
      {/* Floating Toggle Button when Collapsed: Anchored to Bottom-Left */}
      {isCollapsed && (
        <button
          type="button"
          tabIndex={-1}
          onClick={e => {
            e.currentTarget.blur();
            sound.playClick();
            onToggleCollapsed();
          }}
          onPointerDown={e => {
            e.stopPropagation();
            e.currentTarget.blur();
          }}
          className="fixed bottom-4 left-4 z-40 px-3.5 py-2 rounded-xl bg-stone-900/95 hover:bg-stone-850 text-amber-300 font-bold text-xs border border-stone-700 shadow-xl flex items-center gap-1.5 transition active:scale-95 cursor-pointer outline-none focus:outline-none"
        >
          <ChevronUp size={16} />
          <span>コントロール表示 (H)</span>
        </button>
      )}

      {/* Main Unified Control Dock Panel (Bottom Center) */}
      <div
        onPointerDown={e => e.stopPropagation()}
        className={`fixed bottom-3 sm:bottom-4 left-1/2 -translate-x-1/2 w-[95vw] max-w-4xl z-30 select-none flex flex-col items-start transition-all duration-300 ${
          isCollapsed ? 'translate-y-[150%] opacity-0 pointer-events-none' : 'translate-y-0 opacity-100'
        }`}
      >
        {/* Collapse Button: Positioned on the LEFT side */}
        <div className="w-full flex items-center justify-between mb-1.5 px-1">
          <button
            type="button"
            tabIndex={-1}
            onClick={e => {
              e.currentTarget.blur();
              sound.playClick();
              onToggleCollapsed();
            }}
            onPointerDown={e => {
              e.stopPropagation();
              e.currentTarget.blur();
            }}
            className="px-3 py-1 rounded-xl bg-stone-900/90 hover:bg-stone-850 text-stone-300 hover:text-white text-xs font-semibold border border-stone-800 shadow-md flex items-center gap-1.5 transition cursor-pointer outline-none focus:outline-none"
          >
            <ChevronDown size={14} />
            <span>コントロールを隠す (H)</span>
          </button>

          {/* Keyboard Shortcuts Quick Bar */}
          <div className="hidden sm:flex items-center gap-3 text-[11px] font-mono text-stone-400 bg-stone-900/80 px-3 py-1 rounded-xl border border-stone-800">
            <span>← / → 狙い</span>
            <span>↑ / ↓ パワー</span>
            <span>+ / - 仰角</span>
            <span>V 視点</span>
            <span>H 格納</span>
            <span>SPACE 投擲</span>
          </div>
        </div>

        {/* Inner Card */}
        <div className="w-full bg-stone-950/95 border border-stone-800 rounded-3xl p-3 sm:p-4 shadow-[0_12px_40px_rgba(0,0,0,0.7)]">
          {isWaitingNextTurn ? (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 py-2 px-2">
              <div className="text-center sm:text-left">
                <div className="text-amber-400 font-bold text-sm">
                  判定完了：倒れたスキットルはその場で直立します
                </div>
                <div className="text-stone-400 text-xs">
                  モルック棒を回収し、次の投擲準備が整いました
                </div>
              </div>

              <button
                type="button"
                tabIndex={-1}
                onClick={e => {
                  e.currentTarget.blur();
                  sound.playClick();
                  onNextTurnReady();
                }}
                onPointerDown={e => e.currentTarget.blur()}
                className="w-full sm:w-auto px-8 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-950 font-black text-base shadow-[0_4px_16px_rgba(245,158,11,0.4)] hover:brightness-110 active:scale-95 transition cursor-pointer flex items-center justify-center gap-2 outline-none"
              >
                <Play size={18} className="fill-current" />
                次の投擲へ (SPACE)
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {/* Upper Row: Independent Sliders without keyboard focus traps */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {/* 1. Aim Angle */}
                <div
                  className="bg-stone-900/90 rounded-2xl p-2.5 border border-stone-800 flex flex-col justify-between"
                  onPointerDown={e => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-stone-300">
                      <Sliders size={13} className="text-amber-400" />
                      <span>左右の狙い (← / →)</span>
                    </div>
                    <span className="font-mono text-xs font-black text-amber-400 tabular-nums">
                      {throwParams.aimAngle > 0
                        ? `右 +${throwParams.aimAngle}°`
                        : throwParams.aimAngle < 0
                        ? `左 ${throwParams.aimAngle}°`
                        : '中央 0°'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      tabIndex={-1}
                      onClick={e => {
                        e.currentTarget.blur();
                        sound.playClick();
                        updateParam('aimAngle', Math.max(-25, throwParams.aimAngle - 1));
                      }}
                      onPointerDown={e => e.currentTarget.blur()}
                      className="w-7 h-7 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold transition flex items-center justify-center cursor-pointer outline-none"
                      title="左へ微調整 (←キー)"
                    >
                      ◀
                    </button>

                    <input
                      type="range"
                      min="-25"
                      max="25"
                      step="0.5"
                      tabIndex={-1}
                      value={throwParams.aimAngle}
                      onChange={e => updateParam('aimAngle', parseFloat(e.target.value))}
                      onPointerDown={e => e.stopPropagation()}
                      className="flex-1 accent-amber-500 h-1.5 bg-stone-700 rounded-lg cursor-pointer outline-none"
                    />

                    <button
                      type="button"
                      tabIndex={-1}
                      onClick={e => {
                        e.currentTarget.blur();
                        sound.playClick();
                        updateParam('aimAngle', Math.min(25, throwParams.aimAngle + 1));
                      }}
                      onPointerDown={e => e.currentTarget.blur()}
                      className="w-7 h-7 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold transition flex items-center justify-center cursor-pointer outline-none"
                      title="右へ微調整 (→キー)"
                    >
                      ▶
                    </button>
                  </div>
                </div>

                {/* 2. Pitch Angle */}
                <div
                  className="bg-stone-900/90 rounded-2xl p-2.5 border border-stone-800 flex flex-col justify-between"
                  onPointerDown={e => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-stone-300">
                      <span>📐 仰角 (+ / - キー)</span>
                    </div>
                    <span className="font-mono text-xs font-black text-amber-400 tabular-nums">
                      {throwParams.pitchAngle}°
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-stone-500">低空 10°</span>
                    <input
                      type="range"
                      min="10"
                      max="35"
                      step="1"
                      tabIndex={-1}
                      value={throwParams.pitchAngle}
                      onChange={e => updateParam('pitchAngle', parseFloat(e.target.value))}
                      onPointerDown={e => e.stopPropagation()}
                      className="flex-1 accent-amber-500 h-1.5 bg-stone-700 rounded-lg cursor-pointer outline-none"
                    />
                    <span className="text-[10px] text-stone-500">山なり 35°</span>
                  </div>
                </div>

                {/* 3. Power Meter */}
                <div
                  className="bg-stone-900/90 rounded-2xl p-2.5 border border-stone-800 flex flex-col justify-between"
                  onPointerDown={e => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-stone-300">
                      <span>⚡ 投擲パワー (↑ / ↓)</span>
                    </div>
                    <span className="font-mono text-xs font-black text-amber-400 tabular-nums">
                      {throwParams.power}%
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-stone-500">10%</span>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      step="1"
                      tabIndex={-1}
                      value={throwParams.power}
                      onChange={e => updateParam('power', parseFloat(e.target.value))}
                      onPointerDown={e => e.stopPropagation()}
                      className="flex-1 accent-amber-500 h-1.5 bg-stone-700 rounded-lg cursor-pointer outline-none"
                    />
                    <span className="text-[10px] text-stone-500">100% (超遠投)</span>
                  </div>

                  {/* Power Presets */}
                  <div className="flex gap-1.5 mt-1.5">
                    {[
                      { label: '弱め (手前)', val: 30 },
                      { label: '標準 (中心)', val: 55 },
                      { label: '強め (奥)', val: 78 },
                      { label: '最大遠投', val: 100 },
                    ].map(p => (
                      <button
                        key={p.val}
                        type="button"
                        tabIndex={-1}
                        onClick={e => {
                          e.currentTarget.blur();
                          sound.playClick();
                          updateParam('power', p.val);
                        }}
                        onPointerDown={e => e.currentTarget.blur()}
                        className={`flex-1 py-0.5 rounded text-[10px] font-medium transition cursor-pointer outline-none ${
                          Math.abs(throwParams.power - p.val) < 4
                            ? 'bg-amber-500/30 text-amber-300 border border-amber-500/50'
                            : 'bg-stone-800 text-stone-400 hover:text-stone-200'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom Row */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-stone-800/80">
                {/* Camera Views (V key toggleable) */}
                <div className="flex items-center gap-1 bg-stone-900/80 p-1 rounded-xl border border-stone-800">
                  <span className="text-[10px] font-bold text-stone-400 px-1.5 hidden sm:inline">視点 (V):</span>
                  {(
                    [
                      { id: 'thrower', label: '投擲' },
                      { id: 'overhead', label: '俯瞰' },
                      { id: 'target', label: 'ピン' },
                    ] as const
                  ).map(c => (
                    <button
                      key={c.id}
                      type="button"
                      tabIndex={-1}
                      onClick={e => {
                        e.currentTarget.blur();
                        sound.playClick();
                        onChangeCameraView(c.id);
                      }}
                      onPointerDown={e => e.currentTarget.blur()}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer outline-none ${
                        cameraView === c.id
                          ? 'bg-amber-500 text-stone-950 shadow-sm'
                          : 'text-stone-300 hover:text-white hover:bg-stone-800'
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>

                {/* Utility Toggles */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={e => {
                      e.currentTarget.blur();
                      sound.playClick();
                      onToggleTrajectory();
                    }}
                    onPointerDown={e => e.currentTarget.blur()}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer outline-none ${
                      showTrajectory
                        ? 'bg-red-950/70 border-red-500/60 text-red-300'
                        : 'bg-stone-900/80 border-stone-800 text-stone-400 hover:text-stone-200'
                    }`}
                    title="赤色軌道予測ライン表示切替"
                  >
                    <Eye size={13} className={showTrajectory ? 'text-red-400' : ''} />
                    <span className="hidden sm:inline">赤色軌道予測</span>
                  </button>

                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={e => {
                      e.currentTarget.blur();
                      sound.playClick();
                      onToggleSound();
                    }}
                    onPointerDown={e => e.currentTarget.blur()}
                    className="p-2 rounded-xl bg-stone-900/80 hover:bg-stone-800 text-stone-300 hover:text-white border border-stone-800 transition cursor-pointer outline-none"
                    title={soundEnabled ? 'サウンドOFF' : 'サウンドON'}
                  >
                    {soundEnabled ? <Volume2 size={15} /> : <VolumeX size={15} />}
                  </button>

                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={e => {
                      e.currentTarget.blur();
                      sound.playClick();
                      onResetPinsToStarting();
                    }}
                    onPointerDown={e => e.currentTarget.blur()}
                    className="p-2 rounded-xl bg-stone-900/80 hover:bg-stone-800 text-stone-400 hover:text-stone-200 border border-stone-800 transition cursor-pointer outline-none"
                    title="ピンを初期配置に再セット"
                  >
                    <RotateCcw size={15} />
                  </button>
                </div>

                {/* Primary Throw Button */}
                <button
                  type="button"
                  tabIndex={-1}
                  disabled={!canThrow || isSettling || isThrowCooldown}
                  onClick={e => {
                    e.currentTarget.blur();
                    if (canThrow && !isSettling && !isThrowCooldown) {
                      onThrow();
                    }
                  }}
                  onPointerDown={e => e.currentTarget.blur()}
                  className={`flex-1 sm:flex-initial sm:min-w-[200px] py-3 px-6 rounded-2xl font-black text-base tracking-wide flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg active:scale-95 outline-none ${
                    isSettling
                      ? 'bg-stone-800 text-stone-400 cursor-wait border border-stone-700/50'
                      : isThrowCooldown
                      ? 'bg-amber-950/50 text-amber-400 border border-amber-600/50 cursor-not-allowed'
                      : canThrow
                      ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-stone-950 shadow-[0_6px_22px_rgba(245,158,11,0.45)]'
                      : 'bg-stone-800 text-stone-500 cursor-not-allowed border border-stone-700/50'
                  }`}
                >
                  {isSettling ? (
                    <span className="animate-pulse">判定中...</span>
                  ) : isThrowCooldown ? (
                    <span className="text-xs font-bold text-amber-300">狙い調整中 (構え)</span>
                  ) : (
                    <>
                      <Sparkles size={18} className="fill-current" />
                      <span>投げる！ (SPACE)</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};
