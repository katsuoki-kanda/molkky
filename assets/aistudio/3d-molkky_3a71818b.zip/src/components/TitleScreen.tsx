import React from 'react';
import { Play, BookOpen, Volume2, VolumeX } from 'lucide-react';
import { sound } from '../audio/soundEffects';

interface TitleScreenProps {
  onStart: () => void;
  onOpenRules: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStart,
  onOpenRules,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-between p-6 sm:p-10 pointer-events-none select-none">
      {/* Top Bar */}
      <div className="flex items-center justify-between w-full pointer-events-auto">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-stone-900/80 text-amber-200 text-xs font-semibold tracking-wider uppercase border border-amber-500/30">
          <span>🪵 Official Rules</span>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
          <span>Single Player 3D</span>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            onToggleSound();
          }}
          className="p-2.5 rounded-full bg-stone-900/80 hover:bg-stone-800 text-stone-300 hover:text-white border border-stone-700 transition"
          title={soundEnabled ? 'ミュート' : 'サウンドON'}
        >
          {soundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
        </button>
      </div>

      {/* Center Title Lockup */}
      <div className="flex flex-col items-center text-center my-auto pointer-events-auto max-w-xl mx-auto">
        {/* Custom Wood-themed Title */}
        <div className="relative mb-3">
          <div className="inline-block px-4 py-1 rounded bg-amber-950/70 text-amber-300 text-sm font-bold tracking-widest uppercase border border-amber-600/40 shadow-inner">
            Finnish Wood Throwing Sport
          </div>
          <h1 className="text-5xl sm:text-7xl font-black tracking-tight text-amber-50 drop-shadow-[0_4px_16px_rgba(0,0,0,0.6)] mt-2">
            MÖLKKY
            <span className="block text-2xl sm:text-3xl font-extrabold text-amber-400 mt-1 tracking-normal">
              3D モルック マスターズ
            </span>
          </h1>
        </div>

        <p className="text-stone-200 text-sm sm:text-base font-medium max-w-md bg-stone-950/70 p-3 rounded-xl border border-stone-800/80 shadow-lg mt-3">
          モルック棒を投げてスキットルを倒し、<br className="hidden sm:inline" />
          <strong className="text-amber-400 font-bold">ちょうど50点</strong>を目指せ！
          50点を超えると25点に戻るリアルルール。
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3.5 mt-6 w-full max-w-xs sm:max-w-md">
          <button
            onClick={() => {
              sound.playClick();
              onStart();
            }}
            className="w-full sm:flex-1 py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-stone-950 font-black text-lg tracking-wide shadow-[0_8px_25px_rgba(245,158,11,0.4)] active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play size={22} className="fill-current" />
            ゲームスタート (Enter)
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenRules();
            }}
            className="w-full sm:w-auto py-3.5 px-5 rounded-2xl bg-stone-900/80 hover:bg-stone-800/90 text-stone-200 hover:text-white font-bold text-sm border border-stone-700/80 shadow-lg transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
          >
            <BookOpen size={18} />
            ルール説明
          </button>
        </div>

        {/* Single Control Hint line per game craft directives */}
        <div className="mt-5 text-xs text-stone-300 font-mono tracking-wide bg-stone-950/70 px-4 py-2 rounded-full border border-stone-800 shadow-md">
          Space 投擲 · ← → 狙い · ↑ ↓ パワー · + - 仰角 · V 視点 · H 収納
        </div>
      </div>

      {/* Bottom Footer Credit */}
      <div className="text-center text-xs text-stone-400">
        Authentic Finnish Molkky Rules & Real 3D Physics
      </div>
    </div>
  );
};
