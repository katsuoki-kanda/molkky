/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { MolkkyScene } from './game/MolkkyScene';
import { CameraViewMode, GamePhase, ThrowParams, ThrowRecord } from './types/game';
import { TitleScreen } from './components/TitleScreen';
import { HUD } from './components/HUD';
import { ControlDock } from './components/ControlDock';
import { RulesModal } from './components/RulesModal';
import { GameOverModal } from './components/GameOverModal';
import { sound } from './audio/soundEffects';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<MolkkyScene | null>(null);

  // Game state
  const [phase, setPhase] = useState<GamePhase>('title');
  const [score, setScore] = useState<number>(0);
  const [missStreak, setMissStreak] = useState<number>(0);
  const [round, setRound] = useState<number>(1);
  const [history, setHistory] = useState<ThrowRecord[]>([]);

  // Controls & View settings
  const [throwParams, setThrowParams] = useState<ThrowParams>({
    aimAngle: 0,
    pitchAngle: 22,
    power: 55,
    spin: 0,
  });
  const [cameraView, setCameraView] = useState<CameraViewMode>('thrower');
  const [showTrajectory, setShowTrajectory] = useState<boolean>(true);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isControlsCollapsed, setIsControlsCollapsed] = useState<boolean>(false);

  // Throw Safety Cooldown: Prevents accidental Space/Enter throws immediately upon game start or turn change
  const [isThrowCooldown, setIsThrowCooldown] = useState<boolean>(false);
  const throwCooldownUntilRef = useRef<number>(0);

  // UI Modals & Banners
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);
  const [lastBanner, setLastBanner] = useState<{
    message: string;
    sub?: string;
    type: 'success' | 'bust' | 'miss' | 'info';
  } | null>(null);
  const [isWaitingNextTurn, setIsWaitingNextTurn] = useState<boolean>(false);

  // Mouse / Touch drag on canvas to aim
  const dragStartRef = useRef<{ x: number; y: number; aim: number; power: number } | null>(null);

  // Keep latest state in ref for callbacks
  const stateRef = useRef({
    score,
    missStreak,
    round,
    history,
    throwParams,
    phase,
    cameraView,
    isWaitingNextTurn,
  });
  useEffect(() => {
    stateRef.current = {
      score,
      missStreak,
      round,
      history,
      throwParams,
      phase,
      cameraView,
      isWaitingNextTurn,
    };
  }, [score, missStreak, round, history, throwParams, phase, cameraView, isWaitingNextTurn]);

  // Activate throw safety cooldown whenever entering aiming mode
  const activateThrowCooldown = useCallback((durationMs: number = 750) => {
    throwCooldownUntilRef.current = Date.now() + durationMs;
    setIsThrowCooldown(true);
    setTimeout(() => {
      setIsThrowCooldown(false);
    }, durationMs);
  }, []);

  // Initialize Three.js scene once
  useEffect(() => {
    if (!mountRef.current) return;

    const scene = new MolkkyScene(mountRef.current);
    sceneRef.current = scene;

    scene.updateTrajectory(throwParams, showTrajectory);

    return () => {
      scene.dispose();
      sceneRef.current = null;
    };
  }, []);

  // Sync trajectory line when parameters change
  useEffect(() => {
    if (sceneRef.current) {
      sceneRef.current.updateTrajectory(throwParams, showTrajectory && phase === 'aiming');
    }
  }, [throwParams, showTrajectory, phase]);

  // Handle camera view change
  const handleChangeCameraView = useCallback((mode: CameraViewMode) => {
    setCameraView(mode);
    if (sceneRef.current) {
      sceneRef.current.setCameraView(mode);
    }
  }, []);

  // Cycle camera view sequentially with V key
  const handleCycleCameraView = useCallback(() => {
    const cur = stateRef.current.cameraView;
    const views: CameraViewMode[] = ['thrower', 'overhead', 'target'];
    const curIdx = views.indexOf(cur);
    const nextIdx = (curIdx + 1) % views.length;
    const nextMode = views[nextIdx];
    handleChangeCameraView(nextMode);
  }, [handleChangeCameraView]);

  // Sound toggle
  const handleToggleSound = useCallback(() => {
    setSoundEnabled(prev => {
      const next = !prev;
      sound.enabled = next;
      return next;
    });
  }, []);

  // Trajectory toggle
  const handleToggleTrajectory = useCallback(() => {
    setShowTrajectory(prev => !prev);
  }, []);

  // Reset pins to starting cluster (practice feature)
  const handleResetPins = useCallback(() => {
    if (sceneRef.current) {
      sceneRef.current.physics.resetToStartingCluster();
      setLastBanner({
        message: 'スキットルを初期密集陣形に再配置しました',
        type: 'info',
      });
      setTimeout(() => setLastBanner(null), 3000);
      activateThrowCooldown(600);
    }
  }, [activateThrowCooldown]);

  // Handle Round Settlement when all objects stop moving
  const handleRoundSettled = useCallback((fallenPins: number[]) => {
    const { score: curScore, missStreak: curMiss, round: curRound } = stateRef.current;
    const fallenCount = fallenPins.length;

    let roundScore = 0;
    let isBust = false;
    let isMiss = false;
    let nextScore = curScore;
    let nextMissStreak = curMiss;

    if (fallenCount === 0) {
      isMiss = true;
      nextMissStreak = curMiss + 1;
      sound.playMissSound();

      if (nextMissStreak >= 3) {
        setMissStreak(3);
        setPhase('gameover');
        return;
      } else {
        setLastBanner({
          message: `❌ 全ミス！ 0本倒れ (ストライク ${nextMissStreak}/3)`,
          sub: '3回連続ミスで失格になります',
          type: 'miss',
        });
      }
    } else if (fallenCount === 1) {
      const pinNum = fallenPins[0];
      roundScore = pinNum;
      nextMissStreak = 0;
      const testScore = curScore + roundScore;

      if (testScore === 50) {
        nextScore = 50;
        setScore(50);
        setPhase('victory');
        return;
      } else if (testScore > 50) {
        isBust = true;
        nextScore = 25;
        sound.playBustSound();
        setLastBanner({
          message: `💥 50点オーバー！ (現在 ${testScore}点)`,
          sub: '公式ルールにより25点に減点ペナルティ！',
          type: 'bust',
        });
      } else {
        nextScore = testScore;
        sound.playScoreChime(roundScore);
        setLastBanner({
          message: `🎯 スキットル【${pinNum}】を1本撃破！ +${roundScore}点`,
          sub: `合計: ${nextScore}点 (あと ${50 - nextScore}点)`,
          type: 'success',
        });
      }
    } else {
      roundScore = fallenCount;
      nextMissStreak = 0;
      const testScore = curScore + roundScore;

      if (testScore === 50) {
        nextScore = 50;
        setScore(50);
        setPhase('victory');
        return;
      } else if (testScore > 50) {
        isBust = true;
        nextScore = 25;
        sound.playBustSound();
        setLastBanner({
          message: `💥 50点オーバー！ (現在 ${testScore}点)`,
          sub: '公式ルールにより25点に減点ペナルティ！',
          type: 'bust',
        });
      } else {
        nextScore = testScore;
        sound.playScoreChime(roundScore);
        setLastBanner({
          message: `🎳 ${fallenCount}本倒した！ +${roundScore}点`,
          sub: `倒れたピン: [${fallenPins.sort((a, b) => a - b).join(', ')}]`,
          type: 'success',
        });
      }
    }

    const record: ThrowRecord = {
      round: curRound,
      fallenCount,
      fallenNumbers: [...fallenPins],
      roundScore,
      totalScoreBefore: curScore,
      totalScoreAfter: nextScore,
      isBust,
      isMiss,
    };

    setHistory(prev => [record, ...prev]);
    setScore(nextScore);
    setMissStreak(nextMissStreak);
    setIsWaitingNextTurn(true);
  }, []);

  // Prepare next throw: stand pins up at their current landing spots, reset stick
  const handleNextTurnReady = useCallback(() => {
    if (!sceneRef.current) return;
    setIsWaitingNextTurn(false);
    setLastBanner(null);

    sceneRef.current.physics.standPinsBackUpAtCurrentPositions();
    sceneRef.current.physics.resetStickPosition();
    sceneRef.current.setCameraView('thrower');
    setCameraView('thrower');

    setRound(r => r + 1);
    setPhase('aiming');
    activateThrowCooldown(750);
  }, [activateThrowCooldown]);

  // Throw action: Protected against premature or accidental triggers
  const handleThrow = useCallback(() => {
    if (phase !== 'aiming' || isWaitingNextTurn || !sceneRef.current) return;

    if (Date.now() < throwCooldownUntilRef.current) {
      return;
    }

    setPhase('throwing');
    setIsWaitingNextTurn(false);
    setLastBanner(null);

    sceneRef.current.setCameraView('follow');
    setCameraView('follow');

    sceneRef.current.physics.throwStick(
      throwParams.aimAngle,
      throwParams.pitchAngle,
      throwParams.power,
      throwParams.spin,
      fallenPins => {
        handleRoundSettled(fallenPins);
      }
    );
  }, [phase, isWaitingNextTurn, throwParams, handleRoundSettled]);

  // Restart entire match
  const handleRestartGame = useCallback(() => {
    setScore(0);
    setMissStreak(0);
    setRound(1);
    setHistory([]);
    setIsWaitingNextTurn(false);
    setLastBanner({
      message: 'ゲームを最初からリセットしました',
      type: 'info',
    });
    setTimeout(() => setLastBanner(null), 2500);
    setPhase('aiming');

    if (sceneRef.current) {
      sceneRef.current.physics.resetToStartingCluster();
      sceneRef.current.physics.resetStickPosition();
      sceneRef.current.setCameraView('thrower');
      setCameraView('thrower');
    }
    activateThrowCooldown(800);
  }, [activateThrowCooldown]);

  // Start game from title
  const handleStartGame = useCallback(() => {
    setPhase('aiming');
    if (sceneRef.current) {
      sceneRef.current.setCameraView('thrower');
      setCameraView('thrower');
    }
    activateThrowCooldown(800);
  }, [activateThrowCooldown]);

  // High-priority global keyboard event listener with CAPTURE phase:
  // Intercepts H, V, Arrows, +/-, and Space/Enter before any focused element can swallow them
  // and prevents Space from accidentally clicking focused UI buttons
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;

      const key = e.key ? e.key.toLowerCase() : '';

      // 1. 'H' key ALWAYS toggles control dock collapse (immune to focus/IME)
      const isH = e.code === 'KeyH' || key === 'h' || e.keyCode === 72;
      if (isH) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();
        sound.playClick();
        setIsControlsCollapsed(prev => !prev);
        return;
      }

      // 2. 'V' key ALWAYS cycles camera views
      const isV = e.code === 'KeyV' || key === 'v' || e.keyCode === 86;
      if (isV) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();
        sound.playClick();
        handleCycleCameraView();
        return;
      }

      // 3. Arrow keys: Adjust Aim and Power without being trapped by inputs
      if (e.code === 'ArrowLeft' || e.keyCode === 37) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();
        setThrowParams(prev => ({
          ...prev,
          aimAngle: Math.max(-25, Number((prev.aimAngle - 1).toFixed(1))),
        }));
        return;
      }
      if (e.code === 'ArrowRight' || e.keyCode === 39) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();
        setThrowParams(prev => ({
          ...prev,
          aimAngle: Math.min(25, Number((prev.aimAngle + 1).toFixed(1))),
        }));
        return;
      }
      if (e.code === 'ArrowUp' || e.keyCode === 38) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();
        setThrowParams(prev => ({
          ...prev,
          power: Math.min(100, prev.power + 3),
        }));
        return;
      }
      if (e.code === 'ArrowDown' || e.keyCode === 40) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();
        setThrowParams(prev => ({
          ...prev,
          power: Math.max(10, prev.power - 3),
        }));
        return;
      }

      // 4. '+' / '-' keys: Pitch (山なり / 低空)
      const isPlus =
        e.key === '+' ||
        e.key === ';' ||
        e.code === 'Equal' ||
        e.code === 'NumpadAdd' ||
        e.keyCode === 187 ||
        e.keyCode === 107;
      const isMinus =
        e.key === '-' ||
        e.code === 'Minus' ||
        e.code === 'NumpadSubtract' ||
        e.keyCode === 189 ||
        e.keyCode === 109;

      if (isPlus) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();
        setThrowParams(prev => ({
          ...prev,
          pitchAngle: Math.min(35, prev.pitchAngle + 1),
        }));
        return;
      }
      if (isMinus) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();
        setThrowParams(prev => ({
          ...prev,
          pitchAngle: Math.max(10, prev.pitchAngle - 1),
        }));
        return;
      }

      // 5. Space / Enter logic:
      const isSpace = e.code === 'Space' || e.key === ' ' || e.keyCode === 32;
      const isEnter = e.code === 'Enter' || e.key === 'Enter' || e.keyCode === 13;

      if (isSpace || isEnter) {
        // ALWAYS prevent default so Space NEVER triggers browser clicks on focused buttons!
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();

        if (isEnter && phase === 'title') {
          handleStartGame();
          return;
        }

        if (isWaitingNextTurn) {
          handleNextTurnReady();
          return;
        }

        if (phase === 'aiming' && !isWaitingNextTurn) {
          if (Date.now() >= throwCooldownUntilRef.current) {
            handleThrow();
          }
          return;
        }
      }

      // Direct Camera Numbers
      if (e.code === 'Digit1') {
        handleChangeCameraView('thrower');
      } else if (e.code === 'Digit2') {
        handleChangeCameraView('overhead');
      } else if (e.code === 'Digit3') {
        handleChangeCameraView('target');
      } else if (e.code === 'KeyR' && e.shiftKey) {
        handleRestartGame();
      }
    };

    // Use { capture: true } so this listener intercepts before ANY element can click or swallow
    window.addEventListener('keydown', handleKeyDown, { capture: true });
    return () => window.removeEventListener('keydown', handleKeyDown, { capture: true });
  }, [
    phase,
    isWaitingNextTurn,
    handleStartGame,
    handleNextTurnReady,
    handleThrow,
    handleChangeCameraView,
    handleCycleCameraView,
    handleRestartGame,
  ]);

  // Mouse & Touch Drag on Canvas ONLY (never on UI controls)
  const handleCanvasPointerDown = (e: React.PointerEvent) => {
    if (phase !== 'aiming' || isWaitingNextTurn) return;
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      aim: throwParams.aimAngle,
      power: throwParams.power,
    };
  };

  const handleCanvasPointerMove = (e: React.PointerEvent) => {
    if (!dragStartRef.current || phase !== 'aiming' || isWaitingNextTurn) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;

    const deltaAim = (dx / window.innerWidth) * 45;
    const newAim = Math.max(-25, Math.min(25, Number((dragStartRef.current.aim + deltaAim).toFixed(1))));

    const deltaPower = (-dy / window.innerHeight) * 75;
    const newPower = Math.max(10, Math.min(100, Math.round(dragStartRef.current.power + deltaPower)));

    setThrowParams(prev => ({
      ...prev,
      aimAngle: newAim,
      power: newPower,
    }));
  };

  const handleCanvasPointerUp = () => {
    dragStartRef.current = null;
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-stone-950 font-sans select-none">
      {/* 1. Dedicated WebGL Canvas Container with isolated pointer drag handlers */}
      <div
        ref={mountRef}
        className="absolute inset-0 z-0 touch-none cursor-grab active:cursor-grabbing"
        onPointerDown={handleCanvasPointerDown}
        onPointerMove={handleCanvasPointerMove}
        onPointerUp={handleCanvasPointerUp}
        onPointerCancel={handleCanvasPointerUp}
      />

      {/* 2. Title Screen Overlay */}
      {phase === 'title' && (
        <TitleScreen
          onStart={handleStartGame}
          onOpenRules={() => setIsRulesOpen(true)}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
        />
      )}

      {/* 3. In-Game HUD */}
      {phase !== 'title' && (
        <HUD
          score={score}
          missStreak={missStreak}
          round={round}
          history={history}
          lastBanner={lastBanner}
          onResetGame={handleRestartGame}
          onOpenRules={() => setIsRulesOpen(true)}
        />
      )}

      {/* 4. Unified Ergonomic Bottom Control Dock with H key toggle */}
      {phase !== 'title' && phase !== 'victory' && phase !== 'gameover' && (
        <ControlDock
          throwParams={throwParams}
          onChangeParams={setThrowParams}
          onThrow={handleThrow}
          canThrow={phase === 'aiming' && !isWaitingNextTurn && !isThrowCooldown}
          isSettling={phase === 'throwing'}
          cameraView={cameraView}
          onChangeCameraView={handleChangeCameraView}
          showTrajectory={showTrajectory}
          onToggleTrajectory={handleToggleTrajectory}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
          onResetPinsToStarting={handleResetPins}
          isWaitingNextTurn={isWaitingNextTurn}
          onNextTurnReady={handleNextTurnReady}
          isCollapsed={isControlsCollapsed}
          onToggleCollapsed={() => setIsControlsCollapsed(c => !c)}
          isThrowCooldown={isThrowCooldown}
        />
      )}

      {/* 5. Rules Modal */}
      <RulesModal isOpen={isRulesOpen} onClose={() => setIsRulesOpen(false)} />

      {/* 6. Victory / Game Over Modal */}
      {(phase === 'victory' || phase === 'gameover') && (
        <GameOverModal
          type={phase === 'victory' ? 'victory' : 'disqualified'}
          score={score}
          history={history}
          onRestart={handleRestartGame}
        />
      )}
    </div>
  );
}
