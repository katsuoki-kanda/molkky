import * as CANNON from 'cannon-es';
import * as THREE from 'three';
import { sound } from '../audio/soundEffects';

export interface PinPhysicsData {
  id: number;
  number: number;
  body: CANNON.Body;
  mesh: THREE.Group;
  initialPos: { x: number; y: number; z: number };
  isFallen: boolean;
}

export class MolkkyPhysics {
  public world: CANNON.World;
  public pins: PinPhysicsData[] = [];
  public stickBody: CANNON.Body | null = null;
  public stickMesh: THREE.Group | null = null;
  public groundBody: CANNON.Body;

  public pinRadius = 0.08;
  public pinHeight = 0.40;
  public stickRadius = 0.07;
  public stickLength = 0.42;

  private woodMaterial: CANNON.Material;
  private groundMaterial: CANNON.Material;

  public isSettling = false;
  private settleTimer = 0;
  private throwTimer = 0;
  private hasThrown = false;
  private onSettleCallback: ((fallenPins: number[]) => void) | null = null;

  constructor() {
    this.world = new CANNON.World({
      gravity: new CANNON.Vec3(0, -9.82, 0),
    });
    this.world.allowSleep = true;

    this.woodMaterial = new CANNON.Material('wood');
    this.groundMaterial = new CANNON.Material('ground');

    // Contact between wood and wood
    const woodWoodContact = new CANNON.ContactMaterial(this.woodMaterial, this.woodMaterial, {
      friction: 0.45,
      restitution: 0.38,
      contactEquationStiffness: 1e7,
      contactEquationRelaxation: 3,
    });
    this.world.addContactMaterial(woodWoodContact);

    // Contact between wood and grass ground
    const woodGroundContact = new CANNON.ContactMaterial(this.woodMaterial, this.groundMaterial, {
      friction: 0.65,
      restitution: 0.20,
      contactEquationStiffness: 1e7,
      contactEquationRelaxation: 3,
    });
    this.world.addContactMaterial(woodGroundContact);

    // Ground plane
    const groundShape = new CANNON.Plane();
    this.groundBody = new CANNON.Body({
      mass: 0,
      material: this.groundMaterial,
      shape: groundShape,
    });
    this.groundBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);
    this.world.addBody(this.groundBody);
  }

  /**
   * Initializes pins in official Finnish Molkky cluster layout.
   */
  public setupOfficialPinLayout(skittleMeshes: { [num: number]: THREE.Group }) {
    this.pins.forEach(p => {
      this.world.removeBody(p.body);
    });
    this.pins = [];

    const d = this.pinRadius * 2 + 0.015; // ~0.175m center-to-center spacing
    const rowStep = d * 0.866;
    const baseZ = 3.5;

    const layout = [
      // Row 1
      { num: 1, x: -d * 0.5, z: baseZ },
      { num: 2, x: d * 0.5, z: baseZ },
      // Row 2
      { num: 3, x: -d, z: baseZ + rowStep },
      { num: 10, x: 0, z: baseZ + rowStep },
      { num: 4, x: d, z: baseZ + rowStep },
      // Row 3
      { num: 5, x: -d * 1.5, z: baseZ + rowStep * 2 },
      { num: 11, x: -d * 0.5, z: baseZ + rowStep * 2 },
      { num: 12, x: d * 0.5, z: baseZ + rowStep * 2 },
      { num: 6, x: d * 1.5, z: baseZ + rowStep * 2 },
      // Row 4
      { num: 7, x: -d, z: baseZ + rowStep * 3 },
      { num: 9, x: 0, z: baseZ + rowStep * 3 },
      { num: 8, x: d, z: baseZ + rowStep * 3 },
    ];

    layout.forEach((item, id) => {
      const mesh = skittleMeshes[item.num];
      const shape = new CANNON.Cylinder(this.pinRadius, this.pinRadius, this.pinHeight, 16);

      const body = new CANNON.Body({
        mass: 0.42,
        material: this.woodMaterial,
        linearDamping: 0.20,
        angularDamping: 0.30,
      });
      body.addShape(shape);

      const yPos = this.pinHeight / 2;
      body.position.set(item.x, yPos, item.z);
      body.quaternion.set(0, 0, 0, 1);
      this.world.addBody(body);

      body.addEventListener('collide', (event: { contact: { getImpactVelocityAlongNormal: () => number } }) => {
        const vel = Math.abs(event.contact.getImpactVelocityAlongNormal());
        if (vel > 0.35) {
          sound.playWoodImpact(vel * 0.85);
        }
      });

      this.pins.push({
        id,
        number: item.num,
        body,
        mesh,
        initialPos: { x: item.x, y: yPos, z: item.z },
        isFallen: false,
      });

      mesh.position.set(item.x, yPos, item.z);
      mesh.quaternion.set(0, 0, 0, 1);
    });
  }

  /**
   * Sets up or resets the Molkky throwing stick
   */
  public setupStick(stickMesh: THREE.Group) {
    if (this.stickBody) {
      this.world.removeBody(this.stickBody);
    }
    this.stickMesh = stickMesh;

    const shape = new CANNON.Cylinder(this.stickRadius, this.stickRadius, this.stickLength, 16);
    const q = new CANNON.Quaternion();
    q.setFromAxisAngle(new CANNON.Vec3(0, 0, 1), Math.PI / 2);

    this.stickBody = new CANNON.Body({
      mass: 0.45,
      material: this.woodMaterial,
      linearDamping: 0.08,
      angularDamping: 0.15,
    });
    this.stickBody.addShape(shape, new CANNON.Vec3(0, 0, 0), q);

    this.resetStickPosition();
    this.world.addBody(this.stickBody);

    this.stickBody.addEventListener('collide', (event: { contact: { getImpactVelocityAlongNormal: () => number } }) => {
      const vel = Math.abs(event.contact.getImpactVelocityAlongNormal());
      if (vel > 0.3) {
        sound.playWoodImpact(vel * 1.1);
      }
    });
  }

  public resetStickPosition() {
    if (!this.stickBody) return;
    this.stickBody.velocity.set(0, 0, 0);
    this.stickBody.angularVelocity.set(0, 0, 0);
    this.stickBody.position.set(0, 0.7, -0.2);
    this.stickBody.quaternion.set(0, 0, 0, 1);
    this.stickBody.type = CANNON.Body.KINEMATIC;

    if (this.stickMesh) {
      this.stickMesh.position.set(0, 0.7, -0.2);
      this.stickMesh.quaternion.set(0, 0, 0, 1);
      this.stickMesh.visible = true;
    }
    this.hasThrown = false;
    this.isSettling = false;
    this.settleTimer = 0;
    this.throwTimer = 0;
  }

  /**
   * Throws the Molkky stick.
   * Expanded power range: 10% (gentle 2.2 m/s) to 100% (powerful 14.3 m/s).
   */
  public throwStick(
    aimAngleDeg: number,
    pitchAngleDeg: number,
    powerPercent: number,
    spin: number,
    onSettle: (fallenPins: number[]) => void
  ) {
    if (!this.stickBody) return;
    this.onSettleCallback = onSettle;
    this.hasThrown = true;
    this.isSettling = false;
    this.settleTimer = 0;
    this.throwTimer = 0;

    this.pins.forEach(p => {
      p.body.wakeUp();
    });

    this.stickBody.type = CANNON.Body.DYNAMIC;
    this.stickBody.wakeUp();

    // Expanded speed range for high-power long-distance throws
    const speed = 1.5 + Math.pow(powerPercent / 100, 1.25) * 12.8;

    const aimRad = -THREE.MathUtils.degToRad(aimAngleDeg);
    const pitchRad = THREE.MathUtils.degToRad(pitchAngleDeg);

    const horizSpeed = speed * Math.cos(pitchRad);
    const vx = horizSpeed * Math.sin(aimRad);
    const vy = speed * Math.sin(pitchRad);
    const vz = horizSpeed * Math.cos(aimRad);

    this.stickBody.velocity.set(vx, vy, vz);

    const tumbleSpin = 10 + (powerPercent / 100) * 14;
    const sideSpin = spin * 2;
    this.stickBody.angularVelocity.set(-tumbleSpin, sideSpin, 0);

    sound.playThrowWhoosh(powerPercent / 100);
  }

  public step(dt: number) {
    const fixedDt = 1 / 60;
    const maxSubSteps = 3;
    this.world.step(fixedDt, dt, maxSubSteps);

    // Sync pins
    for (const p of this.pins) {
      p.mesh.position.copy(p.body.position as unknown as THREE.Vector3);
      p.mesh.quaternion.copy(p.body.quaternion as unknown as THREE.Quaternion);
    }

    // Sync stick
    if (this.stickBody && this.stickMesh && this.hasThrown) {
      this.stickMesh.position.copy(this.stickBody.position as unknown as THREE.Vector3);
      this.stickMesh.quaternion.copy(this.stickBody.quaternion as unknown as THREE.Quaternion);
    }

    if (this.hasThrown) {
      this.throwTimer += dt;

      let allCalm = true;
      const speedThreshold = 0.08;
      const angThreshold = 0.20;

      if (
        this.stickBody &&
        (this.stickBody.velocity.length() > speedThreshold || this.stickBody.angularVelocity.length() > angThreshold)
      ) {
        allCalm = false;
      }

      for (const p of this.pins) {
        if (p.body.velocity.length() > speedThreshold || p.body.angularVelocity.length() > angThreshold) {
          allCalm = false;
          break;
        }
      }

      if (allCalm && this.throwTimer > 1.2) {
        this.settleTimer += dt;
      } else {
        this.settleTimer = 0;
      }

      if ((this.settleTimer > 0.60 || this.throwTimer > 5.5) && !this.isSettling) {
        this.isSettling = true;
        this.resolveRoundOutcome();
      }
    }
  }

  public evaluateFallenPins(): number[] {
    const fallen: number[] = [];
    const upVector = new CANNON.Vec3(0, 1, 0);

    for (const p of this.pins) {
      const pinWorldUp = p.body.quaternion.vmult(upVector);
      const isFallen = pinWorldUp.y < 0.70 || p.body.position.y < (this.pinHeight * 0.35);
      p.isFallen = isFallen;
      if (isFallen) {
        fallen.push(p.number);
      }
    }
    return fallen;
  }

  private resolveRoundOutcome() {
    const fallenNumbers = this.evaluateFallenPins();
    if (this.onSettleCallback) {
      this.onSettleCallback(fallenNumbers);
    }
  }

  public standPinsBackUpAtCurrentPositions() {
    const yPos = this.pinHeight / 2;

    for (const p of this.pins) {
      if (p.isFallen) {
        const curX = p.body.position.x;
        const curZ = p.body.position.z;

        p.body.position.set(curX, yPos, curZ);
        p.body.quaternion.set(0, 0, 0, 1);
        p.body.velocity.set(0, 0, 0);
        p.body.angularVelocity.set(0, 0, 0);
        p.body.wakeUp();

        p.mesh.position.set(curX, yPos, curZ);
        p.mesh.quaternion.set(0, 0, 0, 1);
        p.isFallen = false;
      } else {
        p.body.velocity.set(0, 0, 0);
        p.body.angularVelocity.set(0, 0, 0);
      }
    }
  }

  public resetToStartingCluster() {
    const d = this.pinRadius * 2 + 0.015;
    const rowStep = d * 0.866;
    const baseZ = 3.5;

    const layout = [
      { num: 1, x: -d * 0.5, z: baseZ },
      { num: 2, x: d * 0.5, z: baseZ },
      { num: 3, x: -d, z: baseZ + rowStep },
      { num: 10, x: 0, z: baseZ + rowStep },
      { num: 4, x: d, z: baseZ + rowStep },
      { num: 5, x: -d * 1.5, z: baseZ + rowStep * 2 },
      { num: 11, x: -d * 0.5, z: baseZ + rowStep * 2 },
      { num: 12, x: d * 0.5, z: baseZ + rowStep * 2 },
      { num: 6, x: d * 1.5, z: baseZ + rowStep * 2 },
      { num: 7, x: -d, z: baseZ + rowStep * 3 },
      { num: 9, x: 0, z: baseZ + rowStep * 3 },
      { num: 8, x: d, z: baseZ + rowStep * 3 },
    ];

    layout.forEach(item => {
      const p = this.pins.find(pin => pin.number === item.num);
      if (p) {
        const yPos = this.pinHeight / 2;
        p.body.position.set(item.x, yPos, item.z);
        p.body.quaternion.set(0, 0, 0, 1);
        p.body.velocity.set(0, 0, 0);
        p.body.angularVelocity.set(0, 0, 0);
        p.mesh.position.set(item.x, yPos, item.z);
        p.mesh.quaternion.set(0, 0, 0, 1);
        p.isFallen = false;
        p.body.wakeUp();
      }
    });

    this.resetStickPosition();
  }
}
